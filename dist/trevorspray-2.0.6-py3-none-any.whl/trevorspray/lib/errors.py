class TREVORSprayError(Exception):
    pass